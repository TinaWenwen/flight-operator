create trigger update_gdsdesctime
  before UPDATE
  on hotelorder
  for each row
  begin
if NEW.gdsdesc is null and OLD.gdsdesc is not null then
set NEW.gdsdesctime=NOW();
elseif NEW.gdsdesc is not null and OLD.gdsdesc is null then
set NEW.gdsdesctime=NOW();
elseif NEW.gdsdesc!=OLD.gdsdesc then
set NEW.gdsdesctime=NOW();
end if;
end;

