create trigger item2itemdetail
  before INSERT
  on ITEM_DIC
  for each row
  BEGIN
    if new.detailitem is null then
        set new.detailitem=CONCAT(new.item_id,'');
    end if;
END;

