create function getParentDeptId(orgid int)
  returns varchar(4000)
  BEGIN
DECLARE oTemp VARCHAR(4000);
DECLARE oTempChild VARCHAR(4000);
DECLARE OldOrgid VARCHAR(4000);

SET oTemp = '';
SET OldOrgid = 0;

WHILE orgid IS NOT NULL AND orgid != OldOrgid
DO
if orgid > 0 then 
SET oTemp = CONCAT(orgid,',',oTemp);
end if ;
SET OldOrgid = orgid ;
SELECT parent_id INTO orgid FROM sso_dept WHERE id=orgid ;
END WHILE;
RETURN oTemp;
END;

